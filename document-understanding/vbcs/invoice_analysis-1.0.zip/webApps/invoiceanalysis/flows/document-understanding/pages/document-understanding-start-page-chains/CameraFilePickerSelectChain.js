define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'ojs/ojarraydataprovider'
], (
  ActionChain,
  Actions,
  ActionUtils,
  ArrayDataProvider
) => {
  'use strict';

  class CameraFilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application } = context;

      const callComponentMethodOjDialogProcessingOpenResult = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-processing',
        method: 'open',
      });

      $page.variables.holdImage = files[0];
      $page.variables.imageURL = URL.createObjectURL($page.variables.holdImage);
      $page.variables.progressMsgVar = "Uploading Invoice...";


      let processedDocInfo = {};
      let processedDocLineInfo = {};

      const uploadFileResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageService/uploadFile',
        uriParams: {
          bucketName: $page.variables.bucketName,
          namespaceName: $page.variables.namespaceName,
          objectName: $page.variables.holdImage.name,
        },
        body: $page.variables.holdImage,
        contentType: $page.variables.holdImage.type,
      }, { id: 'uploadFile' });

      if (!uploadFileResult.ok) {
      
        const callComponentMethodOjDialogProcessingCloseResult = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-processing',
          method: 'close',
        });
        await Actions.fireNotificationEvent(context, {
          summary: "Upload File - Error" + uploadFileResult.body.code,
          message: uploadFileResult.body.message,
        });

        return;
      } else {
        $page.variables.progressMsgVar = "Analyzing Invoice...";
      }

      const createDocumentProcessorJobResult = await Actions.callRest(context, {
        endpoint: 'DocumentUnderstandingService/createDocProcessorJob',
        body: {
        "processorConfig": {
          "processorType": "GENERAL",
          "features": [
            {
              "featureType": "KEY_VALUE_EXTRACTION"
            },
            {
              "featureType": "DOCUMENT_CLASSIFICATION",
              "maxResults": 1
            }
          ]
        },
        "inputLocation": {
          "sourceType": "OBJECT_STORAGE_LOCATIONS",
          "objectLocations": [
            {
              "bucketName": $page.variables.bucketName,
              "namespaceName": $page.variables.namespaceName,
              "objectName": $page.variables.holdImage.name
            }
          ]
        },
        "outputLocation": {
          "bucketName": $page.variables.bucketName,
          "namespaceName": $page.variables.namespaceName,
          "prefix": "result"
        },
        "compartmentId": $page.variables.compartmentId
      },
      }, { id: 'createDocumentProcessorJob' });

      if (!createDocumentProcessorJobResult.ok) {
        const callComponentMethodOjDialogProcessingClose2Result = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-processing',
          method: 'close',
        });

        await Actions.fireNotificationEvent(context, {
          summary: "Create Document Processor Job - " + createDocumentProcessorJobResult.body.code,
          message: createDocumentProcessorJobResult.body.message,
        });
      
        return;
      } else {
        $page.variables.progressMsgVar = "Getting Results...";
      }

      const getResultsObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageService/getFile',
        uriParams: {
          bucketName: $page.variables.bucketName,
          namespaceName: $page.variables.namespaceName,
          'namespace_bucket': $page.variables.namespaceName + "_" + $page.variables.bucketName,
          fileName: $page.variables.holdImage.name + ".json",
          jobId: createDocumentProcessorJobResult.body.id,
        },
      }, { id: 'getResultsObject' });

      if (!getResultsObjectResult.ok) {
        const callComponentMethodOjDialogProcessingClose3Result = await Actions.callComponentMethod(context, {
          selector: '#oj-dialog-processing',
          method: 'close',
        });

        await Actions.fireNotificationEvent(context, {
          summary: "Get Results Object - " + getResultsObjectResult.body.code,
          message: getResultsObjectResult.body.message,
        });
      
        return;
      } else {
        getResultsObjectResult.body.pages[0].documentFields.forEach((element) => {
          processedDocInfo[element.fieldLabel.name] = element.fieldValue.value;
        });
        $page.variables.InvoiceDetailsVar = processedDocInfo;
        $page.variables.LineItemsADP.data = [];

        let lineItemsArr = getResultsObjectResult.body.pages[0].documentFields.find(element => element.fieldType === "LINE_ITEM_GROUP");
        lineItemsArr.fieldValue.items.forEach((items) => {
          items.fieldValue.items.forEach((item) => {
            if(item.fieldType === "LINE_ITEM_FIELD")
              processedDocLineInfo[item.fieldLabel.name] = item.fieldValue.value;
          });
          $page.variables.LineItemsADP.data.push(processedDocLineInfo);
        });
      }

      const callComponentMethodOjDialogProcessingClose4Result = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog-processing',
        method: 'close',
      });
    }
  }

  return CameraFilePickerSelectChain;
});
