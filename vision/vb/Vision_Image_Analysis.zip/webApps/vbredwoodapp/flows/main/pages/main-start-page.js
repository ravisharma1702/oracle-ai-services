/* Copyright (c) 2023, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  var PageModule = function PageModule() {
  };

  PageModule.prototype.processImage = function(file){
      return new Promise(resolve => {
        const blobURL = URL.createObjectURL(file);
        const reader = new FileReader();
        reader.addEventListener("load", function(){
          resolve({
            data: reader.result,
          });
        }, false);

        if(file){
          reader.readAsDataURL(file);
        }
      });
    };

  PageModule.prototype.parseResponse = function(imageAnalysisReponse) {
      try {
        const data = JSON.parse(imageAnalysisReponse);
        const objectCounts = {};

        data.imageObjects.forEach(object => {
          const name = object.name;
          objectCounts[name] = (objectCounts[name] || 0) + 1;
        });

        const result = Object.keys(objectCounts).map(key => {
          return { object: key, count: objectCounts[key] };
        });

        return result;
      } catch (error) {
        console.error("Error parsing JSON:", error);
        return null;
      }
    };

  return PageModule;
});
