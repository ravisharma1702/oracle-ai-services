define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ImagePickerChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.uploadedImage',
          '$page.variables.analyzeImageServiceResponseADPVar.data',
        ],
      });

      $page.variables.progressVar = -1;

      const callFunctionResult = await $page.functions.processImage(files[0]);

      $page.variables.uploadedImage = callFunctionResult.data;

      const callRestIcsPostPOCIMAGERECOGNITIO10AnalyzeImageResult = await Actions.callRest(context, {
        endpoint: 'ics/postPOC_IMAGE_RECOGNITIO1_0AnalyzeImage',
        body: files[0],
      });

      if (!callRestIcsPostPOCIMAGERECOGNITIO10AnalyzeImageResult.ok) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Image Analysis Failed',
          message: 'Error encountered while calling Image Analysis service: ' + callRestIcsPostPOCIMAGERECOGNITIO10AnalyzeImageResult.statusTextcallRestIcsPostPOCIMAGERECOGNITIO10AnalyzeImageResult.statusText,
        });

        $page.variables.progressVar = 100;
      
        return;
      } else {
        
        const parseResponseResult = await $page.functions.parseResponse(JSON.stringify(callRestIcsPostPOCIMAGERECOGNITIO10AnalyzeImageResult.body));
        $page.variables.analyzeImageServiceResponseADPVar.data = parseResponseResult;
        $page.variables.progressVar = 100;
      }
    }
  }

  return ImagePickerChain;
});
